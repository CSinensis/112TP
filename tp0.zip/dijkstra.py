class Graph(object):
    def __init__(self):
        self.graph = dict()
    
    def addEdge(self,nodeA,nodeB,weight):
        self.graph[nodeA] = self.graph.get(nodeA,dict())
        self.graph[nodeB] = self.graph.get(nodeB,dict())
        self.graph[nodeA][nodeB] = weight
        self.graph[nodeB][nodeA] = weight

    def getEdgeWeight(self,nodeA,nodeB):
        return self.graph[nodeA][nodeB]
    
    def getNodes(self):
        return list(self.graph)
    
    def getNeighbors(self,node):
        return set(self.graph[node])
    
    def orderedNeighbors(self,node):
        L = []
        for neighbor in self.getNeighbors(node):
            L.append((self.getEdgeWeight(node,neighbor),neighbor))
        return sorted(L)

#BFS
def BFS(graph,root):
    seen = {}
    seen.add(root)
    Q = [root]
    while len(Q) > 0:
        node = Q.pop()
        for i in graph.getNeighbors(node):
            if i not in seen:
                Q.append(i)
                seen.add(i)


# def dijkWrapper(graph,start,end):
#     return dijkstra(graph,start,end,[])

# def dijkstra(graph,start,end,stack):
#     if start == end:
#         return stack
#     for node in graph[start]:
#         pathLen,path = graph[start][node],(start,node)
#         if stack == []:
#             stack.append((pathLen,path))
#         else:
#             for i in range(len(stack)):
#                 if stack[i][0] > pathLen:
#                     stack.insert((pathLen,path),i)
#             if (pathLen,path) not in stack:         
#                 stack.append((pathLen,path))
#     return stack

testGraph = {
    'A':{'B':2,'C':4},
    'B':{'A':2,'C':3,'D':8},
    'C':{'A':4,'B':3,'E':5,'D':2},
    'D':{'B':8,'C':2,'E':11,'F':22},
    'E':{'C':5,'D':11,'F':1},
    'F':{'D':22,'E':1}
}

#dijkstra(testGraph,'A','F')