from cmu_112_graphics import *
import math
def appStarted(app):
    app.cubes = [Cube('red',20,app.width/2,0),Cube('Blue',20,app.width/2+10,0)]
    app.timerDelay = 10
    return 42

def keyPressed(app,event):
    if event.key == "Right":
        app.cubes[0].cx += 10
    elif event.key == "Left":
        app.cubes[0].cx -= 10
    elif event.key == "Up":
        app.cubes[0].t = 0
        app.cubes[0].vy = 10
        app.cubes[0].jump = True
    elif event.key == "d":
        app.cubes[1].cx += 10
    elif event.key == "a":
        app.cubes[1].cx -= 10
    elif event.key == "w":
        app.cubes[1].t = 0
        app.cubes[1].vy = 10
        app.cubes[1].jump = True

def drawCubes(app,canvas):
    for cube in app.cubes:
        x = cube.cx
        y = cube.cy
        w = cube.size
        canvas.create_rectangle(x-w,y-w,x+w,y+w,fill = cube.color)

def drawTerrain(app,canvas):
    canvas.create_rectangle(0,app.height/2,app.width,app.height,fill="blue")

def redrawAll(app,canvas):
    drawTerrain(app,canvas)
    drawCubes(app,canvas)

class Cube(object):
    def __init__(self,color,size,cx,cy):
        self.color = color
        self.size = size
        self.cx = cx
        self.cy = cy
        self.vx = 0
        self.vy = 0
        self.t = 0
        self.jump = False

def timerFired(app):
    for cube in app.cubes:
        cube.t +=(0.1)
        cube.cy -= cube.vy*cube.t - (1/2)*9.81*(cube.t**2)
        if onTerrain(app,cube): 
            if cube.jump == False:
                cube.cy = app.height/2 - cube.size
        cube.jump = False

def onTerrain(app,cube):
    if cube.cy + cube.size >= app.height/2:
        return True
    return False

def projectileMotion(vx,vy,t):
    if vx == 0:
        vAngle = math.pi/2
    else:
        vAngle = math.atan(vy/vx)
    x = vx*t
    y = vy*t - (1/2)*9.8*(t**2)
    return ()

runApp(width=400,height=400)


    